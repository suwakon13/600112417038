<?php
require "conn.php";

$strSQL = "SELECT * FROM user";
$obj = mysqli_query($link,$strSQL);
// while($rows = mysqli_fetch_array($obj)){
//     echo $rows[0] . "<br>";
// }

?>

<div class="box-body table-responsive">
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>No.</th>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php
            while($row = mysqli_fetch_array($obj)){
            ?>
            <tr>
                <td></td>
                <td><?=$row[0]?></td>
                <td><?=$row[2]?></td>
                <td><?=$row['email']?></td>
                <td><button class="btn btn-danger btn-delUser" data="<?=$row[0]?>">DEL</button></td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<script>
$(".btn-delUser").click(function(){
    //alert($(this).attr("data"));
    var idDel = $(this).attr("data");
    var reqest = $.ajax({
        method: "POST",
        url: "./scripts/delUser.php"
        data: {id : idDel }
    });

    reqest.done(function(){
        $("#showUser").load("./scripts/showUser.php");
    });
});

</script>